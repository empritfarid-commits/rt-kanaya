# RT KANAYA — Vercel Ready

Aplikasi React/Vite untuk administrasi RT, sudah disiapkan untuk deployment ke Vercel.

## 1. Jalankan lokal
```bash
npm install
cp .env.example .env.local
npm run dev
```

Windows PowerShell:
```powershell
Copy-Item .env.example .env.local
npm install
npm run dev
```

## 2. Firebase
Buat Firebase Web App lalu isi variabel `VITE_FIREBASE_*` di `.env.local` atau Vercel Project Settings → Environment Variables.

Aktifkan:
- Authentication → Anonymous
- Firestore Database

Aplikasi memakai collection:
`artifacts/{appId}/public/data/...`

## 3. Gemini
Isi `GEMINI_API_KEY` di Vercel sebagai **server-only environment variable**. Jangan gunakan prefix `VITE_`, agar API key tidak masuk ke bundle browser.

Endpoint AI tersedia di `/api/gemini`.

## 4. Deploy ke Vercel
Upload ZIP ini ke GitHub/GitLab/Bitbucket lalu import repository ke Vercel, atau gunakan Vercel CLI:
```bash
npm i -g vercel
vercel
vercel --prod
```

Set semua environment variable di Vercel sebelum deploy ulang.

## Catatan keamanan penting
Kode sumber awal menggunakan login email/password yang disimpan sebagai field Firestore dan password demo plaintext. Ini dipertahankan agar perilaku prototipe tetap sama, tetapi **tidak cocok untuk produksi**. Untuk aplikasi publik, migrasikan login ke Firebase Authentication (Email/Password/Google) dan gunakan Firestore Security Rules berbasis `request.auth`.

Selain itu, Anonymous Auth harus diaktifkan karena aplikasi melakukan sign-in anonim sebelum membaca Firestore.
