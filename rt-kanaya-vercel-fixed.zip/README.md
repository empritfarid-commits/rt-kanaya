# RT KANAYA — Vercel Ready

Aplikasi React/Vite untuk administrasi RT, sudah disiapkan untuk deployment ke Vercel.

## 1. Jalankan lokal
```bash
npm install
cp .env.example .env.local
npm run dev
```

Windows PowerShell:
```powershell
Copy-Item .env.example .env.local
npm install
npm run dev
```

## 2. Firebase
Buat Firebase Web App lalu isi variabel `VITE_FIREBASE_*` di `.env.local` atau Vercel Project Settings → Environment Variables.

Aktifkan:
- Authentication → Anonymous
- Firestore Database

Aplikasi memakai collection:
`artifacts/{appId}/public/data/...`

## 3. Gemini
Isi `GEMINI_API_KEY` di Vercel sebagai **server-only environment variable**. Jangan gunakan prefix `VITE_`, agar API key tidak masuk ke bundle browser.

Endpoint AI tersedia di `/api/gemini`.

## 4. Deploy ke Vercel
Upload ZIP ini ke GitHub/GitLab/Bitbucket lalu import repository ke Vercel, atau gunakan Vercel CLI:
```bash
npm i -g vercel
vercel
vercel --prod
```

Set semua environment variable di Vercel sebelum deploy ulang.

## Catatan keamanan penting
Kode sumber awal menggunakan login email/password yang disimpan sebagai field Firestore dan password demo plaintext. Ini dipertahankan agar perilaku prototipe tetap sama, tetapi **tidak cocok untuk produksi**. Untuk aplikasi publik, migrasikan login ke Firebase Authentication (Email/Password/Google) dan gunakan Firestore Security Rules berbasis `request.auth`.

Selain itu, Anonymous Auth harus diaktifkan karena aplikasi melakukan sign-in anonim sebelum membaca Firestore.

## Vercel 404 / NOT_FOUND troubleshooting

Make sure the contents of this folder are the repository/project root. In particular, `package.json`, `vercel.json`, `index.html`, `src/`, and `api/` must be directly under the Vercel Root Directory.

For this Vite app, Vercel should use:
- Build Command: `npm run build`
- Output Directory: `dist`

If you deploy from a Git repository, do not put these files under an extra wrapper folder unless you set Vercel's Root Directory to that folder.

The `/api/gemini` endpoint is deployed from `api/gemini.js` and requires `GEMINI_API_KEY` in Vercel Environment Variables.
